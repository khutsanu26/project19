package su.usatu.project26.model;

public class JsonResponse {
	
	public boolean success;
	public String errorMessage;
	public Object responseBody;

}
