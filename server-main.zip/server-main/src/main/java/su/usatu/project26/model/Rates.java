package su.usatu.project26.model;

public class Rates {
	
	public int id; //идентификатор группы тарифов
	
	public double single_rate_price; // Одноставочный тариф
	
	public double daily_rate_price; // Дневная зона
	public double night_rate_price; // Ночная зона
	
	public double peak_zone_rate_price; // Пиковая зона
	public double semipeak_zone_rate_price; // Полупиковая зона
	public double night_zone_rate_price; // Ночная зона
	
}