$('#table_selector').change(function() {
    getDataForInfoPage();

});

getDataForInfoPage();